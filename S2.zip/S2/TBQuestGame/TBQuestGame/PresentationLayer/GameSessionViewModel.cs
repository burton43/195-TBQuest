﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TBQuestGame.Models;
using TBQuestGame;
using System.Windows.Threading;


namespace TBQuestGame.PresentationLayer
{
    public class GameSessionViewModel : ObservableObject
    {
        private Player _player;
        private List<string> _messages;
        private Location[,] _gameMap;
        private int _maxRows, _maxColumns;
        private GameMapCoordinates _currentLocationCoordinates;
        private Location _currentLocation;
        private Location _alphaLocation, _betaLocation, _gammaLocation, _deltaLocation;


        public Player Player
        {
            get { return _player; }
            set { _player = value; }
        }

        public string MessageDisplay
        {
            get { return string.Join("\n\n", _messages); }
        }

        public GameSessionViewModel()
        {

        }

       
        /// <summary>
        /// 
        /// </summary>
        /// 

       

        /// <summary>
        /// travel east (beta)
        /// </summary>
        public void BetaTravel()
        {
            if (HasBetaLocation)
            {
                _currentLocationCoordinates.Column++;
                CurrentLocation = _gameMap[_currentLocationCoordinates.Row, _currentLocationCoordinates.Column];
                UpdateAvailableTravelPoints();
                _player.GetFear += _currentLocation.FearPoints;
            }
        }

       

        /// <summary>
        /// travel west (delta)
        /// </summary>
        public void DeltaTravel()
        {
            if (HasDeltaLocation)
            {
                _currentLocationCoordinates.Column--;
                CurrentLocation = _gameMap[_currentLocationCoordinates.Row, _currentLocationCoordinates.Column];
                UpdateAvailableTravelPoints();
                _player.GetFear += _currentLocation.FearPoints;
            }
        }

       

        public Location[,] GameMap
        {
            get { return _gameMap; }
            set { _gameMap = value; }
        }
        public Location CurrentLocation
        {
            get { return _currentLocation; }
            set
            {
                _currentLocation = value;
                OnPropertyChanged(nameof(CurrentLocation));
            }
        }

        //
        // expose information about travel points from current location
        //
        public Location AlphaLocation
        {
            get { return _alphaLocation; }
            set
            {
                _alphaLocation = value;
                OnPropertyChanged(nameof(AlphaLocation));
                OnPropertyChanged(nameof(HasAlphaLocation));
            }
        }

        public Location BetaLocation
        {
            get { return _betaLocation; }
            set
            {
                _betaLocation = value;
                OnPropertyChanged(nameof(BetaLocation));
                OnPropertyChanged(nameof(HasBetaLocation));
            }
        }

        public Location GammaLocation
        {
            get { return _gammaLocation; }
            set
            {
                _gammaLocation = value;
                OnPropertyChanged(nameof(GammaLocation));
                OnPropertyChanged(nameof(HasGammaLocation));
            }
        }

        public Location DeltaLocation
        {
            get { return _deltaLocation; }
            set
            {
                _deltaLocation = value;
                OnPropertyChanged(nameof(DeltaLocation));
                OnPropertyChanged(nameof(HasDeltaLocation));
            }
        }

        public bool HasAlphaLocation { get { return AlphaLocation != null; } }
        public bool HasBetaLocation { get { return BetaLocation != null; } }
        public bool HasGammaLocation { get { return GammaLocation != null; } }
        public bool HasDeltaLocation { get { return DeltaLocation != null; } }

        private void UpdateAvailableTravelPoints()
        {
            //
            // reset travel location information
            //
            AlphaLocation = null;
            BetaLocation = null;
            GammaLocation = null;
            DeltaLocation = null;
            if (_currentLocationCoordinates.Column > 0)
            {
                Location nextDeltaLocation = _gameMap[_currentLocationCoordinates.Row, _currentLocationCoordinates.Column - 1];
                if (nextDeltaLocation != null && nextDeltaLocation.GetReachable == true) // location exists
                {
                    DeltaLocation = _gameMap[_currentLocationCoordinates.Row, _currentLocationCoordinates.Column - 1];
                }
            }


            if (_currentLocationCoordinates.Column < _maxColumns - 1)
            {
                Location nextBetaLocation = _gameMap[_currentLocationCoordinates.Row, _currentLocationCoordinates.Column + 1];
                if (nextBetaLocation != null && nextBetaLocation.GetReachable == true) // location exists
                {
                    BetaLocation = _gameMap[_currentLocationCoordinates.Row, _currentLocationCoordinates.Column + 1];
                }
            }
        }
        public GameSessionViewModel(
           Player player,
           List<string> initialMessages,
           Location[,] gameMap,
            GameMapCoordinates currentLocationCoordinates)
        {
            _player = player;
            _messages = initialMessages;

            _gameMap = gameMap;
            _maxRows = _gameMap.GetLength(0);
            _maxColumns = _gameMap.GetLength(1);

            _currentLocationCoordinates = currentLocationCoordinates;
            _currentLocation = _gameMap[_currentLocationCoordinates.Row, _currentLocationCoordinates.Column];
            UpdateAvailableTravelPoints();
        }
    }
}
