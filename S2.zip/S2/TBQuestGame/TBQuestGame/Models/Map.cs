﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TBQuestGame.Models
{
    public class Map
    {
        private Location[,] _locations;

        public Location[,] GetLocations
        {
            get { return _locations; }
            set { _locations = value; }
        }

        private Location _currentLocation;

        public Location CurrentLocations
        {
            get { return _currentLocation; }
            set { _currentLocation = value; }
        }

        public Map(int rows, int columns)
        {
            _locations = new Location[rows, columns];
        }
    }
}
