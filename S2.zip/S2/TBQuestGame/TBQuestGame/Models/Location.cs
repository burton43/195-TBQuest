﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TBQuestGame.Models
{
    public class Location
    {
        public string _name;

        public string GetName
        {
            get { return _name; }
            set { _name = value; }
        }

        public int _id;

        public int GetID
        {
            get { return _id; }
            set { _id = value; }
        }

        public string _desc;

        public string GetDescription
        {
            get { return _desc; }
            set { _desc = value; }
        }

        public bool _reach;

        public bool GetReachable
        {
            get { return _reach; }
            set { _reach = value; }
        }
        public int _fear;

        public int FearPoints
        {
            get { return _fear; }
            set { _fear = value; }
        }

    }
}
