﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TBQuestGame.Models;

namespace TBQuestGame.DataLayer
{
    public static class GameData
    {
        public static Player PlayerData()
        {
            return new Player()
            {
                GetID = 1,
                GetName = "Jessie",
                GetLocation = 1,
                Sex = Player.Gender.Man,
                GetScared = false,
                GetFear = 10,
                Inventory = new ObservableCollection<GameItemQuantity>()
                {
                    
                }
            };
        }
        
        public static string InitialMessages(string _messages)
        {
            
            return _messages;
        }

        public static GameMapCoordinates InitialGameMapLocation()
        {
            return new GameMapCoordinates() { Row = 0, Column = 4 };
        }
        private static GameItem GameItemById(int id)
        {
            return StandardGameItems().FirstOrDefault(i => i.Id == id);
        }

        public static Location[,] GameMap()
        {
            int rows = 1;
            int columns = 11;

            Location[,] mapLocations = new Location[rows, columns];

            
            mapLocations[0, 0] = new Location()
            {
                GetID = 0,
                GetName = "Rear of the Caboose",
                GetDescription = "The end of the train. The exit door on back of the train is welded shut.",
                GetReachable = true,
                Accessible =false,
                RequiredItemsId = 4001,
                FearPoints = 10
            };
            mapLocations[0, 1] = new Location()
            {
                GetID = 1,
                GetName = "Front of the Caboose",
                GetDescription = "The Caboose. It appears to have been used as the kitchen area for the dining car.",
                GetReachable = true,
                Accessible =true,
                FearPoints = 10
               
            };

            
            mapLocations[0, 2] = new Location()
            {
                GetID = 2,
                GetName = "Rear of the Dining Car",
                GetDescription = "Cobwebs cover the tables and chairs.",
                GetReachable = true,
                FearPoints = 10,
                Accessible = true
            };
            mapLocations[0, 3] = new Location()
            {
                GetID = 3,
                GetName = "Front of the Dining Car",
                GetDescription = "Cobwebs cover the tables and chairs",
                GetReachable = true,
                FearPoints = 10,
                Accessible = true
            };

            
            mapLocations[0, 4] = new Location()
            {
                GetID = 4,
                GetName = "Rear of the Economy Car",
                GetDescription = "The passenger economy car: the seats are basic and cramped.",
                GetReachable = true,
                FearPoints = 10,
                Accessible = true
            };
            mapLocations[0, 5] = new Location()
            {
                GetID = 5,
                GetName = "Front of the Economy Car",
                GetDescription = "The passenger economy car: the seats are basic and cramped",
                GetReachable = true,
                FearPoints = 10,
                Accessible = true
            };
            mapLocations[0, 6] = new Location()
            {
                GetID = 6,
                GetName = "Rear of the First Class Car",
                GetDescription = "The first class car: the car is divided into seperate rooms with booths",
                GetReachable = true,
                FearPoints = 10,
                Accessible = true
            };
            mapLocations[0, 7] = new Location()
            {
                GetID = 7,
                GetName = "Front of the First Class Car",
                GetDescription = "The first class car: the car is divided into seperate rooms with booths",
                GetReachable = true,
                FearPoints = 10,
                GameItems = new ObservableCollection<GameItemQuantity>
                {
                    new GameItemQuantity(GameItemById(4001), 1)
                },
                Accessible = true
            };
            mapLocations[0, 8] = new Location()
            {
                GetID = 8,
                GetName = "Rear of the Luggage car",
                GetDescription = "Boxes and crates line the walls. It smells like musty cloth. A rat scurries past your feet.",
                GetReachable = true,
                FearPoints = 10,
                Accessible = true
            };
            mapLocations[0, 9] = new Location()
            {
                GetID = 9,
                GetName = "Front of the Luggage car",
                GetDescription = "Large suitcases are stacked neatly.",
                GetReachable = true,
                FearPoints = 10,
                Accessible = true
            };
            mapLocations[0, 10] = new Location()
            {
                GetID = 10,
                GetName = "Cab of the Engine",
                GetDescription = "The front of the train. This is the main engine.",
                GetReachable = true,
                FearPoints = 10,
                Accessible = true
            };

            return mapLocations;
        }

        

        public static List<GameItem> StandardGameItems()
        {
            return new List<GameItem>()
            {
                new Items(4001, "Rusted Key", "A key. It is covered in rust.",  "You have opened the {name of room}.", Items.UseActionType.OPENLOCATION),
                new Items(4002, "Crowbar", "A two foot long steel crowbar. Its been painted black.",  "Wedging the the crowbar into the door opening, you pull hard. With a groan the door slides open.", Items.UseActionType.PRYOPEN)
            };
        }
    }
}
